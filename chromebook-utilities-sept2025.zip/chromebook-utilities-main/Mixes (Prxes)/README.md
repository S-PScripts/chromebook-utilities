# Mixes (Prxes) (UNMAINTAINED)
This folder includes prxes but unlike the prxes folder, they have a focus on other things too! These include many pre-added gxmes and having an app section for popular apps.

https://github.com/wea-f/ByePassHub/blob/main/mainUnblockers.md
