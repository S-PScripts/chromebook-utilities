# Alternatives
This folder features a collection of alternative links for services. 

## Current list:
-> Github <br>
-> Google <br>
-> Google Workspace <br>
-> Fandom <br>
-> Instagram <br>
-> Reddit <br>
-> Scratch <br>
-> StackOverflow <br>
-> TikTok <br>
-> Twitter (X) <br>
-> Wikipedia <br>
-> Youtube Music <br>
-> Youtube <br>
