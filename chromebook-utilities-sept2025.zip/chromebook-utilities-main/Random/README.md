# Random
Things that don't fit into any of the other categories. Possibly for me saying personal stuff.
