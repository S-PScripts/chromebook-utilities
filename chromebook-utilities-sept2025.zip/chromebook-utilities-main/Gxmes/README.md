# Gxmes
## In this folder, you'll find:
-> Lots of gxme websites, each with many links! These are in the Sorted folder. <br>
-> Some larger online gxmes, such as Roblox and Minecraft! These are in the Apps folder. <br>
-> General gxme websites! <br>
-> Emulators for retro gxmes! <br>
-> A guide on how to play retro gxmes! <br>
