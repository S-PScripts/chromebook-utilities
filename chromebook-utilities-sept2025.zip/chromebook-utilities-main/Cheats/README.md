# Cheats
## A collection of cheats for:
-> Blooket <br>
-> Edpuzzle <br>
-> Gimkit <br>
-> Kahoot <br>
-> Quizizz <br>
-> Quizlet <br>
-> and more! <br>
