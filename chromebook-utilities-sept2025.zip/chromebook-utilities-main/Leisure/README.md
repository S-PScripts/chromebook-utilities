# Leisure
## In this folder, you'll find:
-> AIs <br>
-> Maths Solvers <br>
-> Movies and anime <br>
